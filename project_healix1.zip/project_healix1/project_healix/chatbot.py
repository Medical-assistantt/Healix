from flask import Flask, request, jsonify, render_template

from src.helper import (
    create_user_pdf,
    append_output_to_pdf,
    load_ml_dl_artifact,
    parse_symptoms_from_text,
)

from datetime import datetime, timedelta
from pathlib import Path
import base64
import hashlib
import hmac
import json
import uuid
import numpy as np


try:
    # Try to use the rich NLP pipeline and symptom vocabulary from `nlp.py`.
    from nlp import extract_symptoms_from_text as advanced_extract_symptoms, symptoms_list as ADV_SYMPTOM_VOCAB  # type: ignore
except Exception:
    advanced_extract_symptoms = None
    ADV_SYMPTOM_VOCAB = None


app = Flask(__name__, template_folder="templates")

ROOT_DIR = Path(__file__).resolve().parent
DATA_DIR = ROOT_DIR / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)
USERS_FILE = DATA_DIR / "users.json"
REPORTS_FILE = DATA_DIR / "reports.json"
JWT_SECRET = "change-me-in-production"  # simple demo key
JWT_ALG = "HS256"
JWT_EXP_MINUTES = 60


# --- New Specialty Mapping ---
SPECIALTY_MAPPING = {
    # Based on common diseases and visible examples from final_label_encoder.pkl
    "sick sinus syndrome": "Cardiologist",
    "atrophic vaginitis": "Dermatologist",
    "cellulitis or abscess of mouth": "Dermatologist",
    "vaginitis": "Dermatologist",
    "headache after lumbar puncture": "Neurologist",
    "panic disorder": "Neurologist",
    "eye alignment disorder": "Neurologist",
    "glaucoma": "Neurologist", # Can be Optometrist/Ophthalmologist, using Neurologist as a close match
    "cryptorchidism": "Pediatrician",
    "pyloric stenosis": "Pediatrician",
    "turner syndrome": "Pediatrician",
    "fracture of the hand": "Orthopedist",
    "injury to the knee": "Orthopedist",
    "osteochondrosis": "Orthopedist",
}

def get_specialty_recommendation(disease_name: str) -> str:
    """Maps a predicted disease name to a recommended specialist specialty."""
    disease_name_lower = disease_name.lower().strip()
    
    # Check for direct match
    recommended_specialty = SPECIALTY_MAPPING.get(disease_name_lower)
    
    if recommended_specialty:
        return recommended_specialty
    
    # Simple keyword-based fallback for better coverage
    if "pain" in disease_name_lower or "fracture" in disease_name_lower or "injury" in disease_name_lower or "weakness" in disease_name_lower:
        return "Orthopedist"
    if "heart" in disease_name_lower or "sinus" in disease_name_lower or "cardio" in disease_name_lower:
        return "Cardiologist"
    if "skin" in disease_name_lower or "vaginitis" in disease_name_lower or "cellulitis" in disease_name_lower:
        return "Dermatologist"
    if "headache" in disease_name_lower or "nerve" in disease_name_lower or "brain" in disease_name_lower or "panic" in disease_name_lower:
        return "Neurologist"
    if "child" in disease_name_lower or "pediatric" in disease_name_lower or "infant" in disease_name_lower or "syndrome" in disease_name_lower:
        return "Pediatrician"
    
    # Default to General Practitioner if no specific match is found
    return "General Practitioner"
# --- End Specialty Mapping ---


def _load_users():
    if not USERS_FILE.exists():
        return []
    try:
        return json.loads(USERS_FILE.read_text(encoding="utf-8"))
    except Exception:
        return []


def _save_users(users):
    USERS_FILE.write_text(json.dumps(users, indent=2), encoding="utf-8")


def _load_reports():
    if not REPORTS_FILE.exists():
        return []
    try:
        return json.loads(REPORTS_FILE.read_text(encoding="utf-8"))
    except Exception:
        return []


def _save_reports(reports):
    REPORTS_FILE.write_text(json.dumps(reports, indent=2), encoding="utf-8")


def _hash_password(password: str) -> str:
    return hashlib.sha256(password.encode("utf-8")).hexdigest()


def _verify_password(password: str, hashed: str) -> bool:
    return _hash_password(password) == hashed


def _b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _b64url_decode(data: str) -> bytes:
    padding = "=" * (-len(data) % 4)
    return base64.urlsafe_b64decode(data + padding)


def _create_jwt(payload: dict) -> str:
    header = {"alg": JWT_ALG, "typ": "JWT"}
    header_b64 = _b64url_encode(json.dumps(header, separators=(",", ":")).encode("utf-8"))
    payload_b64 = _b64url_encode(json.dumps(payload, separators=(",", ":")).encode("utf-8"))
    signing_input = f"{header_b64}.{payload_b64}".encode("ascii")
    sig = hmac.new(JWT_SECRET.encode("utf-8"), signing_input, hashlib.sha256).digest()
    sig_b64 = _b64url_encode(sig)
    return f"{header_b64}.{payload_b64}.{sig_b64}"


def _verify_jwt(token: str):
    try:
        header_b64, payload_b64, sig_b64 = token.split(".")
        signing_input = f"{header_b64}.{payload_b64}".encode("ascii")
        expected_sig = hmac.new(JWT_SECRET.encode("utf-8"), signing_input, hashlib.sha256).digest()
        if not hmac.compare_digest(expected_sig, _b64url_decode(sig_b64)):
            return None
        payload = json.loads(_b64url_decode(payload_b64))
        exp = payload.get("exp")
        if exp is not None and datetime.utcnow().timestamp() > exp:
            return None
        return payload
    except Exception:
        return None


@app.after_request
def apply_cors(response):
    """
    Allow the React frontend (served from a different origin) to call this API.
    """
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization"
    response.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    return response

# Load classical ML model and required artifacts (USING THE CORRECT FILE NAMES)
ml_model = load_ml_dl_artifact("model_pipeline.pkl")

try:
    # Load required artifacts for prediction/decoding based on the training script
    LABEL_ENCODER = load_ml_dl_artifact("final_label_encoder.pkl")
    SYMPTOM_COLUMNS = load_ml_dl_artifact("symptom_columns.pkl")
    print("DEBUG: Label Encoder and Symptom Columns loaded successfully.")
except Exception as e:
    LABEL_ENCODER = None
    SYMPTOM_COLUMNS = None
    print(f"ERROR: Failed to load required prediction artifacts (LabelEncoder/Symptoms). Prediction will fail. Exception: {e}")


user_info = {}


def _handle_chat_message(user_text: str) -> dict:
    """
    Core chatbot logic shared by both the legacy `/get` endpoint
    and the newer `/api/chatbot/message` endpoint.
    """
    global user_info

    # 1. Determine Current State
    current_state = user_info.get("state", "new_session")
    
    # --- Conversational Flow (State Machine) ---
    if current_state == "new_session":
        user_info["state"] = "waiting_for_name"
        # Initial greeting/prompt
        # Note: If user says "Hello" or similar, the current logic treats it as the name.
        return {"answer": "Welcome to the Healix Chatbot. Please introduce yourself (full name):"}

    elif current_state == "waiting_for_name":
        user_info["name"] = user_text.strip()
        user_info["state"] = "waiting_for_age"
        return {"answer": f"Thank you, {user_info['name']}. Please enter your age:"}
    
    elif current_state == "waiting_for_age":
        user_info["age"] = user_text.strip()
        user_info["state"] = "waiting_for_gender"
        return {"answer": "Please enter your gender (e.g., Male/Female/Other):"}
        
    elif current_state == "waiting_for_gender":
        user_info["gender"] = user_text.strip()
        user_info["state"] = "waiting_for_chronic_diseases"
        return {"answer": "Do you have any chronic diseases (e.g., diabetes, hypertension)? Please specify, or reply 'None'."}
    
    elif current_state == "waiting_for_chronic_diseases":
        user_info["chronic_diseases"] = user_text.strip()
        user_info["state"] = "waiting_for_surgeries"
        return {"answer": "Have you had any surgeries in the past? If so, please specify, or reply 'None'."}
    
    elif current_state == "waiting_for_surgeries":
        user_info["past_surgeries"] = user_text.strip()
        user_info["state"] = "waiting_for_symptom_history"
        return {"answer": "Is this the first time you are experiencing these symptoms, or have you suffered from them before? Please specify the duration and frequency (e.g., 'First time', '3 weeks ago', 'Recurrent for several months')."}
    
    elif current_state == "waiting_for_symptom_history":
        user_info["symptom_history"] = user_text.strip()
        user_info["state"] = "symptom_collection_active"

        # Initialize the PDF report with collected demographics
        create_user_pdf(user_info["name"], user_info["age"], user_info["gender"]) 
        
        return {
            "answer": "Thank you for providing your medical background. Now, please describe at least 3 of your current symptoms with their intensity and duration."
        }
    
    # Check if we are in the active symptom collection phase
    if user_info.get("state") != "symptom_collection_active":
        # Fallback for unexpected state after initial setup
        return {"answer": "I am ready to process your symptoms. Please describe them with detail."}


    # --- NLP extraction ---
    if advanced_extract_symptoms is not None:
        symptoms = advanced_extract_symptoms(user_text)
    else:
        symptoms = parse_symptoms_from_text(user_text)
        
    # Standardize symptoms (e.g., lowercase) to match column names in SYMPTOM_COLUMNS
    extracted_symptoms_lower = [s.lower() for s in symptoms]
    
    if not symptoms:
        return {
            "answer": "I couldn't reliably extract symptoms from that. Please describe your symptoms with more detail."
        }

    # --- Classical ML prediction using the .pkl model ---
    ml_pred_value = None
    recommended_specialty = None
    
    if ml_model is None or LABEL_ENCODER is None or SYMPTOM_COLUMNS is None:
        print("DEBUG: Prediction artifacts are missing. Cannot run ML prediction.")
    else:
        try:
            # 1. Create the binary feature vector expected by the RandomForest model
            input_vector = np.zeros(len(SYMPTOM_COLUMNS))
            
            # Populate the vector with '1' for any matched symptom
            for i, col_symptom in enumerate(SYMPTOM_COLUMNS):
                # We check if the standardized extracted symptom is in the list of column names
                if col_symptom in extracted_symptoms_lower:
                    input_vector[i] = 1

            # The model expects a list of samples: [[symptom_vector]]
            X_input = [input_vector]

            # 2. Run prediction (returns an encoded integer)
            ml_pred_encoded = ml_model.predict(X_input)
            
            # 3. Decode the prediction to the actual disease name string
            if hasattr(ml_pred_encoded, "__len__") and len(ml_pred_encoded) == 1:
                ml_pred_int = ml_pred_encoded[0]
                # Use inverse_transform to get the disease name
                ml_pred_value = LABEL_ENCODER.inverse_transform([ml_pred_int])[0]
                
                # --- NEW: Get Specialty Recommendation ---
                recommended_specialty = get_specialty_recommendation(ml_pred_value)
                # --- End NEW ---
            else:
                ml_pred_value = str(ml_pred_encoded)

            print(f"DEBUG: ML Prediction Successful. Decoded Value: {ml_pred_value}, Recommended Specialty: {recommended_specialty}")
            
        except Exception as e:
            ml_pred_value = None
            recommended_specialty = None
            print(f"ERROR: Failed to run ML model prediction! Check input vector shape or model compatibility. Exception: {e}")


    # Build a structured report object for the frontend modal
    predictions_block = {}
    # If successful, the prediction is now stored as a string
    if ml_pred_value is not None:
        # Prediction is stored in the report block with 100% confidence
        predictions_block[str(ml_pred_value)] = 100.0

    report = {
        "report_id": f"rep_{uuid.uuid4().hex[:8]}",
        "timestamp": datetime.utcnow().isoformat(),
        "patient": {
            "name": user_info.get("name", "Unknown"),
            "age": user_info.get("age", "N/A"),
            "gender": user_info.get("gender", "N/A"),
            # NEWLY ADDED FIELDS:
            "chronic_diseases": user_info.get("chronic_diseases", "N/A"),
            "past_surgeries": user_info.get("past_surgeries", "N/A"),
            "symptom_history": user_info.get("symptom_history", "N/A"),
        },
        "symptoms": symptoms,
        "predictions": predictions_block,
        "recommended_doctors": [
            {
                "id": "featured-1",
                "name": "Dr. Ahmed Hassan",
                "specialty": "Cardiologist",
                "experience": "12+ years experience",
            },
            {
                "id": "featured-2",
                "name": "Dr. Fatima Ali",
                "specialty": "Pediatrician",
                "experience": "8+ years experience",
            },
        ],
        "notes": "This report is generated by AI and is not a medical diagnosis. Please consult a licensed physician.",
    }

    # Persist everything in the pseudo-PDF report
    report_payload = {
        "symptoms": symptoms,
        # The ML prediction is saved in the report payload
        "ml_prediction": None if ml_pred_value is None else str(ml_pred_value),
        "structured_report": report,
    }
    append_output_to_pdf(report_payload)

    # Also persist in JSON reports store so the frontend can list them
    reports = _load_reports()
    reports.append(report)
    _save_reports(reports)

    # --- Compose a user-friendly reply (USING SPECIALTY RECOMMENDATION) ---
    reply_parts = []
    
    if ml_pred_value is not None:
        # Prediction successful and logged (but hidden from patient)
        reply_parts.append(
            f"Thank you for describing your symptoms: **{', '.join(symptoms)}**. A detailed medical assessment has been performed and securely logged."
        )
        # --- NEW: Display Recommended Specialty ---
        reply_parts.append(
            f"**Recommendation:** Based on the assessment, the most suitable specialty is **{recommended_specialty}**."
        )
        reply_parts.append(
            "Please check the **Reports** section for the full official assessment, and visit the **Doctors** section to connect with an expert in this field."
        )
    else:
        # Prediction failed or model failed to load
        reply_parts.append(
            "We have logged your symptoms, but the prediction model was unable to produce a reliable result at this time. Please try describing your symptoms in a different way."
        )
        reply_parts.append(
            "We still recommend consulting a specialist. You can find recommended doctors in the **Doctors** section."
        )

    
    final_reply = " ".join(reply_parts)
    # --- End Reply Composition ---

    # Frontend-friendly JSON structure
    primary_prediction = None
    if ml_pred_value is not None:
        # Send the actual prediction, which will be used by the Reports modal in the UI
        primary_prediction = str(ml_pred_value) 

    response_body = {
        "answer": final_reply,
        "symptoms": symptoms,
        # This key remains, allowing the frontend to access the prediction for the modal
        #"prediction": primary_prediction, 
        "recommended specialty": recommended_specialty,
        "confidence": None, 
        # Envelope for the React UI, which expects response.data.report
        "data": {"report": report},
    }

    return response_body


@app.route("/")
def index():
    return render_template("index.html")


# ---------- AUTH & USER MANAGEMENT (NO CHANGE) ----------

@app.route("/api/auth/signup", methods=["POST", "OPTIONS"])
def api_signup():
    if request.method == "OPTIONS":
        return ("", 204)

    payload = request.get_json() or {}
    email = (payload.get("email") or "").strip().lower()
    password = payload.get("password") or ""
    role = payload.get("role") or "patient"

    if not email or not password:
        return jsonify({"success": False, "message": "Email and password are required"}), 400

    users = _load_users()
    if any(u.get("email") == email for u in users):
        return jsonify({"success": False, "message": "User already exists"}), 409

    user_id = f"user_{uuid.uuid4().hex[:8]}"
    user = {
        "id": user_id,
        "fullName": payload.get("fullName") or payload.get("full_name") or "",
        "age": payload.get("age") or "",
        "gender": payload.get("gender") or "",
        "email": email,
        "role": role,
        "specialty": payload.get("specialty") or "",
        "mobile": payload.get("mobile") or "",
        "hospitalCode": payload.get("hospitalCode") or "",
        "password_hash": _hash_password(password),
        "created_at": datetime.utcnow().isoformat(),
    }
    users.append(user)
    _save_users(users)

    token_payload = {
        "sub": user_id,
        "email": email,
        "role": role,
        "exp": (datetime.utcnow() + timedelta(minutes=JWT_EXP_MINUTES)).timestamp(),
    }
    token = _create_jwt(token_payload)

    public_user = {k: v for k, v in user.items() if k != "password_hash"}
    return jsonify({"success": True, "user": public_user, "token": token})


@app.route("/api/auth/login", methods=["POST", "OPTIONS"])
def api_login():
    if request.method == "OPTIONS":
        return ("", 204)

    payload = request.get_json() or {}
    email = (payload.get("email") or "").strip().lower()
    password = payload.get("password") or ""
    role = payload.get("role") or None

    users = _load_users()
    user = next((u for u in users if u.get("email") == email), None)
    if not user or not _verify_password(password, user.get("password_hash", "")):
        return jsonify({"success": False, "message": "Invalid credentials"}), 401

    if role and user.get("role") != role:
        return jsonify({"success": False, "message": "Role does not match this account"}), 401

    token_payload = {
        "sub": user["id"],
        "email": email,
        "role": user.get("role"),
        "exp": (datetime.utcnow() + timedelta(minutes=JWT_EXP_MINUTES)).timestamp(),
    }
    token = _create_jwt(token_payload)

    public_user = {k: v for k, v in user.items() if k != "password_hash"}
    return jsonify({"success": True, "user": public_user, "token": token})


@app.route("/api/auth/me", methods=["GET"])
def api_me():
    auth_header = request.headers.get("Authorization", "")
    if not auth_header.startswith("Bearer "):
        return jsonify({"ok": False}), 401
    token = auth_header.split(" ", 1)[1]
    payload = _verify_jwt(token)
    if not payload:
        return jsonify({"ok": False}), 401
    return jsonify({"ok": True, "user": payload})


@app.route("/api/doctors", methods=["GET"])
def api_doctors():
    users = _load_users()
    doctors = [
        {
            "id": u["id"],
            "name": u.get("fullName") or u.get("full_name") or "Doctor",
            "specialty": u.get("specialty") or "General Practice",
            "experience": "—",
            "email": u.get("email"),
            "mobile": u.get("mobile") or "",
        }
        for u in users
        if u.get("role") == "doctor"
    ]
    return jsonify(doctors)


@app.route("/api/reports", methods=["GET"])
def api_reports():
    """
    Return all saved structured reports.
    In a real app you would filter by authenticated user; for now this
    returns the full list so the frontend can display them.
    """
    reports = _load_reports()
    return jsonify(reports)


# ---------- NEW MESSAGING ENDPOINT (FOR DOCTOR CHAT) ----------
@app.route("/api/messaging/send", methods=["POST", "OPTIONS"])
def api_messaging_send():
    """
    Simulates sending a message to a doctor. In a real application, this
    would save the message to a database and notify the recipient.
    """
    if request.method == "OPTIONS":
        return ("", 204)
        
    data = request.get_json() or {}
    
    # In a real app, we'd check JWT to get sender_id
    sender_id = data.get("sender_id", "Patient_1") # Placeholder
    recipient_id = data.get("recipient_id", "Doctor_X") # Doctor's ID
    message = data.get("message", "")
    
    if not message:
        return jsonify({"success": False, "message": "Message content is required"}), 400
        
    print(f"DEBUG: New message received: Sender={sender_id}, Recipient={recipient_id}, Message='{message[:50]}...'")
    
    # Simulate saving/forwarding the message
    return jsonify({
        "success": True, 
        "message_id": f"msg_{uuid.uuid4().hex[:4]}", 
        "status": "sent",
        "confirmation": f"Your message was successfully sent to {recipient_id}."
    }), 200
# ---------- END NEW MESSAGING ENDPOINT ----------

# Legacy endpoint kept for compatibility
@app.route("/get", methods=["POST"])
def get_bot_response():
    data = request.get_json() or {}
    user_text = data.get("msg", "") or ""
    body = _handle_chat_message(user_text)
    return jsonify(body)


# Primary API endpoint used by the React frontend
@app.route("/api/chatbot/message", methods=["POST", "OPTIONS"])
def api_chatbot_message():
    # Handle CORS preflight
    if request.method == "OPTIONS":
        return ("", 204)

    data = request.get_json() or {}
    # Frontend sends { "message": "...", "session_id": "..." }
    user_text = data.get("message") or data.get("msg") or ""
    body = _handle_chat_message(user_text)
    return jsonify(body)


if __name__ == "__main__":
    app.run(debug=True)